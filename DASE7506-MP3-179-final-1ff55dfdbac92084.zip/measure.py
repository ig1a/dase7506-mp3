"""Run the supplied reproduction script within a four-CPU affinity mask on Linux."""
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
allowed = sorted(os.sched_getaffinity(0))[:4]
os.sched_setaffinity(0, allowed)
start = time.monotonic()
subprocess.run(["bash", str(root / "run.sh"), *sys.argv[1:]], check=True)
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
metrics = dict(wall_seconds=time.monotonic() - start, user_seconds=usage.ru_utime,
               system_seconds=usage.ru_stime, largest_process_rss_kib=usage.ru_maxrss,
               allowed_cpu_count=len(allowed), per_process_as_limit_mib=2048)
(root / "outputs" / f"{sys.argv[1]}-resources.json").write_text(json.dumps(metrics, indent=2) + "\n")
