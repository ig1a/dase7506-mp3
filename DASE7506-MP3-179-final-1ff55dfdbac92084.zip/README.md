# DASE7506 MP3 reproduction

Unpack this private source bundle to a new directory. On Linux with Python 3.12 and four CPU threads, run the commands below. Set BUNDLE to that directory first. Prediction and scoring overwrite the named outputs, so use a fresh copy if preserving the delivered JSON bytes. Network access is only needed for initial provisioning. All predictions and scoring use the official offline tools.

```bash
export BUNDLE=/absolute/path/to/unpacked-bundle
cd "$BUNDLE"
sha256sum -c SHA256SUMS
sha256sum -c FROZEN.sha256
mkdir -p /tmp/dase7506-mp3-reproduction
cd /tmp/dase7506-mp3-reproduction
base=https://raw.githubusercontent.com/xudongwu-0/xudongwu-0.github.io/main/courses/dase7506/mp3/downloads
curl -fsSLO "$base/MP3_SQL_student_package.zip"
curl -fsSLO "$base/MP3_SQL_student_package.zip.sha256"
sha256sum -c MP3_SQL_student_package.zip.sha256
echo '406d69507ccf955a53b35db1c1368bd7452565ebd928b47d0f6161fe35b99a61  MP3_SQL_student_package.zip' | sha256sum -c -
unzip -q MP3_SQL_student_package.zip
cd MP3_SQL_student_package
python3.12 -m venv ../venv
source ../venv/bin/activate
python -m pip install -r requirements.txt
python -m mp3_sql.check_data
bash "$BUNDLE/run.sh" validation early
bash "$BUNDLE/run.sh" validation no-edits
bash "$BUNDLE/run.sh" validation
python "$BUNDLE/measure.py" test
```

The exported factory is submission/submission.py:create_agent. The default uses the frozen full configuration. Experiment JSON overrides one switch each. The original predictor and scorer are invoked by run.sh. The bundle includes complete official test predictions and scores, and the validation scores. Validation predictions can be regenerated with the commands above. The original scorer includes runtime fields and a hash of the complete prediction document, so hashes can change across reruns even with identical trajectories. Compare predictions arrays and per_question score arrays for deterministic reproduction.

The official test trajectories contain unmodified SQLite result rows from the course benchmark, including person names and phone-number fields. These are present in the student package's public examples/executions. Their real-world provenance has not been independently established. The exported controller and accompanying report include no participant contact details or student ID.
