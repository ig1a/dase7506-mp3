"""Feedback-driven CPU SQL repair. No benchmark files or model access."""
import json
import re
from collections import Counter

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError


def parse(sql):
    try:
        trees = sqlglot.parse(sql, read="sqlite")
        if len(trees) == 1 and isinstance(trees[0], exp.Query):
            return trees[0]
    except (SqlglotError, RecursionError):
        pass
    return None


def normalized(sql):
    # Preserve case inside quoted literals and identifiers.
    return sql.strip().rstrip(";").strip()


def header_expr(label, tree):
    # Accept only a column or one simple aggregate from the public header.
    match = re.fullmatch(r"(?:(count|avg|sum|min|max)\(\s*(distinct\s+)?)?(?:[\w]+\.)?(\*|[a-z_]\w*)\s*(\))?", label.strip(), re.I)
    if not match or bool(match[1]) != bool(match[4]):
        return None
    name = match[3]
    known = [c for c in tree.find_all(exp.Column) if c.name.casefold() == name.casefold()
             and c.find_ancestor(exp.Select) is tree]
    field = exp.Star() if name == "*" else (known[0].copy() if known else exp.column(name))
    if not match[1]:
        return field
    if match[2]:
        field = exp.Distinct(expressions=[field])
    return getattr(exp, match[1].capitalize())(this=field)


def variants(tree, headers, question):
    if not isinstance(tree, exp.Select):
        return
    fields = [header_expr(label, tree) for label in headers]
    bases = [tree]
    if fields and all(field is not None for field in fields):
        revised = tree.copy()
        revised.set("expressions", fields)
        bases.insert(0, revised)
        yield revised, "projection"
    for base in bases:
        if not any(item.find(exp.AggFunc) or isinstance(item, exp.Star) for item in base.expressions):
            changed = base.copy()
            changed.set("distinct", None if base.args.get("distinct") else exp.Distinct())
            yield changed, "distinct"
        if base.args.get("limit") and re.search(r"\b(all|every|each)\b", question, re.I):
            changed = base.copy()
            changed.set("limit", None)
            yield changed, "limit"


class RepairAgent:
    def __init__(self, settings):
        self.settings = settings
        self.ranks = {}
        self.queue = []

    def prepare(self, obs, hints):
        original = obs["issue_sql"]
        question = obs["task"]["question"]
        headers = obs["example"]["columns"]
        frequency = Counter(normalized(h) for h in hints if isinstance(h, str))
        sources = list(frequency) + [original]
        want_unique = bool(re.search(r"\b(distinct|unique|different|without duplicates)\b", question, re.I))
        seen = {}

        def add(sql, tree, prior):
            canonical = tree.sql(dialect="sqlite")
            if len(sql.encode()) > 16000:
                return
            signature = 0
            if isinstance(tree, exp.Select):
                labels = [header_expr(h, tree) for h in headers]
                if len(labels) == len(tree.expressions):
                    for field, target in zip(tree.expressions, labels):
                        if target is not None:
                            a = re.sub(r'\b\w+\.', '', field.unalias().sql()).casefold()
                            b = re.sub(r'\b\w+\.', '', target.sql()).casefold()
                            signature += (a == b) / len(labels)
                if tree.args.get("distinct"):
                    prior += 3 if want_unique else -0.9
            rank = prior + 5 * signature
            if canonical not in seen or seen[canonical][1] < rank:
                seen[canonical] = (sql, rank)
            self.ranks[sql] = max(rank, self.ranks.get(sql, -1000))

        for sql in sources:
            tree = parse(sql)
            if tree is None:
                continue
            prior = (2 + 0.28 * frequency[normalized(sql)]) if normalized(sql) in frequency else 0
            add(sql, tree, prior)
            if self.settings["edits"]:
                for edit, kind in variants(tree, headers, question):
                    add(edit.sql(dialect="sqlite"), edit, prior - (0.35 if kind == "projection" else 0.8))
        draft = parse(original)
        draft_key = draft.sql(dialect="sqlite") if draft is not None else ""
        if draft_key in seen:
            self.ranks[original] = seen.pop(draft_key)[1]
        self.queue = [s for s, rank in sorted(seen.values(), key=lambda item: -item[1])]

    def act(self, obs):
        history = obs["history"]
        if not history:
            return {"tool": "check", "sql": obs["issue_sql"]}
        if len(history) == 1:
            return {"tool": "repair_hint"}
        if len(history) == 2:
            self.prepare(obs, history[-1]["observation"])
        checks = [e for e in history if e["tool"] == "check"]
        passes = [e for e in checks if e["observation"]["matches_example"]]
        best = max(passes or checks, key=lambda e: (
            e["observation"]["ok"],
            self.ranks.get(e["sql"], -100),
        ))
        if self.queue and obs["remaining"] and not (passes and self.settings["early"]):
            return {"tool": "check", "sql": self.queue.pop(0)}
        return {"tool": "submit", "sql": best["sql"]}


def create_agent(checkpoint=None):
    settings = {"edits": True, "early": False}
    if checkpoint is not None:
        with open(checkpoint, encoding="utf-8") as config:
            settings.update(json.load(config))
    return RepairAgent(settings)
