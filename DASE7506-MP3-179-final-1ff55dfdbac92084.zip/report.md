# DASE7506 MP3 · SQL Repair Agent

## Result

The frozen CPU controller solved **179 of 240 test tasks (74.58%)** under the official three-instance rule. Validation accuracy was **92 of 120 (76.67%)**. An earlier historical comparison was 174/240 test and 91/120 validation. The present run is higher by five test tasks (2.08 percentage points) and one validation task (0.83 points). The prior implementation was unavailable, so these differences describe reported totals only.

## Controller and feedback

The controller checks the exact draft and reads the shared offline hint. It treats repeated hint strings as votes, parses each distinct hint and the draft, and proposes edits to their outer SELECT. It rebuilds a projection from public example column names, including simple aggregates, toggles DISTINCT on eligible queries, and tries removing a row limit for questions asking for all, every or each. It keeps the underlying source tables and predicates. SQLGlot collapses equivalent serializations before tool checks.

The score combines source prior, hint frequency, agreement with public result headers, a lexical cue for uniqueness and a penalty for edits. The controller checks candidates in this order until the queue or tool budget is exhausted. A registered public-example match outranks a mismatch. Among matching candidates it chooses the highest-ranked one. When every check fails to match, it prefers executable SQL, then uses the same ranking. The eight-call cap includes one draft check and one hint call. Per-task memory consists of the queue, ranks and official episode history. There is no cross-task memory, retrieval index, training or runtime model call.

## Controlled validation experiments

| Configuration | Correct / 120 | Accuracy | Mean charged calls |
|---|---:|---:|---:|
| Full | 92 | 76.67% | 5.175 |
| Disable generated edits only | 81 | 67.50% | 3.050 |
| Stop once any public match is available | 81 | 67.50% | 2.833 |

All rows used the same split, ranking, hint cache and official evaluator. Early stopping still requests the hint after checking the draft but can skip subsequent SQL checks. Each ablation reduced the full score by 11 tasks. The two differences cannot be added. Validation selected the full configuration. Source SHA-256 was recorded in FROZEN.sha256 before test prediction. Test results were used only for reporting and reproduction.

## Cost and limitations

On Linux x86-64, Python 3.12.14 and SQLGlot 27.29.0, the official test predictor took 8.56 s and scoring took 11.86 s. The Linux wrapper measured 20.72 s elapsed, 56.97 user CPU seconds and 15.94 system CPU seconds across descendants. Largest individual-process peak RSS was 32,380 KiB. This measurement excludes simultaneous memory use by other processes. The wrapper restricted execution to four CPU IDs, four workers and a per-process 2 GiB address-space limit. Test cost averaged 4.954 charged calls per task. No GPU, adapter, model weights, tokens or online API calls were used at evaluation time.

Of the 28 validation failures, 15 selected queries missed the public example. For the headquarters question the agent counted people within companies, while the question required counting companies within headquarters. Projection edits retained the wrong grouping. Another 13 selected queries matched the public example and failed the official multi-instance criterion. For the Subway question, filtering a restaurant type returned the expected empty result on the example. That result gave the controller little evidence about which attribute denoted the named restaurant. Ranking by public headers can also favor a column with the right name from the wrong side of a join. These are public-benchmark measurements on disjoint schemas, with validation used for selection.

## Integrity and provenance

Inputs came from the instructor's SHA-256-verified MP3 student package. The official check_data command verified 480 training, 120 validation and 240 test tasks. Development inspected training examples and fixed course hint examples. No parameters were fitted; validation compared configurations. Only the official predictor/environment and scorer accessed databases. The controller has no references, fingerprint inputs, database paths, ID-based answers or access to extra evaluation instances. The older historical results are participant-reported. Spider-derived course material is attributed in the starter NOTICE under CC BY-SA 4.0. The source bundle excludes the starter data and cached hint bank.

Questions, returned strings and cached hint SQL are untrusted data. The controller only uses fixed lexical tests on question text. Public header inputs must match a narrow column/aggregate grammar before being converted to SQL AST nodes. Hints must parse as one query before they enter the queue. No text can choose shell commands, tool names or file paths. SQL execution, including checking the mandatory original draft, goes through the unchanged course read-only executor, which enforces its own restrictions. Misleading but syntactically valid hints can still bias votes and produce a wrong answer.

OpenAI Codex assisted with specification review, writing the controller, experiment design, execution, analysis and report preparation. The course's cached LLM hints are runtime inputs. No external LLM was called by the submitted agent. Reproduction commands are in README.md. Official specification: https://github.com/xudongwu-0/xudongwu-0.github.io/blob/main/courses/dase7506/mp3/PROJECT.md


## Two follow-up validation rounds and final selection

Exactly two candidates were evaluated under a strict validation-improvement rule. Round 1 fit question unigram/bigram statistics for eight SQL structural features on 480 training questions and reference SQL queries. Adding this prior to the candidate ranking yielded 92/120, with zero gained or lost tasks relative to the incumbent. The tie retained the original controller. Round 2 started independently from the incumbent, proposed outer grouping at the requested projection grain, and derived count HAVING alternatives for lexical threshold cues. It gained one validation task and lost none, reaching 93/120. The frozen round-2 candidate then scored 179/240 on the full official test. As specified before scoring, a test tie preserves the previously reproduced controller. This ZIP therefore contains the original 92/120 validation, 179/240 test controller and its own unchanged score and prediction documents. The two candidate implementations and run logs are archived privately and separately. No test result was used to design either candidate.
