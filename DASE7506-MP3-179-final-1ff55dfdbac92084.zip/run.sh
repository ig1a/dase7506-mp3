#!/usr/bin/env bash
set -eu
# Run from the official extracted package with its virtual environment active.
root=$(cd "$(dirname "$0")" && pwd)
split=${1:-validation}
mode=${2:-full}
out="$root/outputs/$split"
args=()
if [[ "$mode" != full ]]; then
    args=(--checkpoint "$root/experiments/$mode.json")
    out="$root/outputs/$split-$mode"
fi
ulimit -v 2097152
python -m mp3_sql.predict --split "$split" --workers 4 --method "$root/submission/submission.py" "${args[@]}" --output "$out.json"
python -m mp3_sql.score --split "$split" --workers 4 --predictions "$out.json" --output "$out-score.json"
